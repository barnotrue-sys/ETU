ETU SNACK KASIR V4.8 - PERBAIKAN KAMERA SCAN & PRINTER

Isi:
- index.html: aplikasi kasir

Perbaikan:
1. Tombol BUKA KAMERA SCAN di halaman Kasir. Meminta izin kamera, membuka kamera belakang, dan membaca barcode jika Android WebView/browser mendukung BarcodeDetector.
2. Tombol TUTUP KAMERA untuk mematikan kamera setelah selesai.
3. Opsi HUBUNGKAN BLUETOOTH untuk printer thermal BLE yang mendukung Web Bluetooth dan karakteristik tulis.
4. Opsi USB/SERIAL tetap tersedia pada browser/perangkat yang mendukung Web Serial.
5. Nama pelanggan, barcode produk, ekspor Excel, penghapusan transaksi admin, laporan dan fitur lain dipertahankan dari basis V4.8.

PENTING:
- Sebelum mengganti APK, ekspor/cadangkan data dari aplikasi lama.
- Kamera hanya bekerja jika aplikasi pembuat APK/WebView mengizinkan akses kamera dan izin CAMERA sudah diaktifkan. Jika tombol memberi pesan izin/dukungan, buka pengaturan aplikasi Android dan izinkan Kamera; bila perlu buat ulang APK dengan permission CAMERA.
- Web Bluetooth hanya bekerja pada browser/WebView yang mendukung navigator.bluetooth dan printer BLE yang kompatibel. Banyak printer thermal Bluetooth klasik (SPP) tidak dapat terhubung langsung dari halaman HTML/WebView. Untuk printer seperti itu gunakan aplikasi cetak pendamping/SDK printer atau buat APK native yang mendukung Bluetooth SPP.
- Web Serial hanya tersedia pada browser/perangkat yang mendukungnya.
- Koneksi kamera dan printer fisik belum dapat diuji di perangkat pengguna; lakukan tes kecil terlebih dahulu.
